library(testthat)
library(MetaboAnalystR)

test_check("MetaboAnalystR")
